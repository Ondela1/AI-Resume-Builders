// DOM Elements
const nameInput = document.getElementById('name');
const contactInput = document.getElementById('contact');
const summaryTextarea = document.getElementById('summary');
const skillsTextarea = document.getElementById('skills');

const aiSuggestSummaryBtn = document.getElementById('aiSuggestSummaryBtn');
const aiSuggestSkillsBtn = document.getElementById('aiSuggestSkillsBtn');

const experienceContainer = document.getElementById('experienceContainer');
const addExperienceBtn = document.getElementById('addExperienceBtn');
const educationContainer = document.getElementById('educationContainer');
const addEducationBtn = document.getElementById('addEducationBtn');

// ATS Compatibility Check elements
const checkAtsBtn = document.getElementById('checkAtsBtn');
const atsResultBox = document.getElementById('atsResultBox');
const atsResultDisplay = document.getElementById('atsResultDisplay');
const atsErrorDisplay = document.getElementById('atsErrorDisplay');

// PDF Template Selector
const pdfTemplateSelect = document.getElementById('pdfTemplate');

// AI Suggestion Box elements
const aiSuggestionBox = document.getElementById('aiSuggestionBox');
const aiSuggestionDisplay = document.getElementById('aiSuggestionDisplay');
const applySuggestionBtn = document.getElementById('applySuggestionBtn');
const provideFeedbackBtn = document.getElementById('provideFeedbackBtn');
const aiErrorDisplay = document.getElementById('aiErrorDisplay');

// Feedback Modal elements
const feedbackModal = document.getElementById('feedbackModal');
const feedbackTextarea = document.getElementById('feedbackTextarea');
const cancelFeedbackBtn = document.getElementById('cancelFeedbackBtn');
const submitFeedbackBtn = document.getElementById('submitFeedbackBtn');

const downloadResumeBtn = document.getElementById('downloadResumeBtn');

// State variables (managed by plain JS)
let isLoading = false;
let currentAiTargetElement = null; // Stores the textarea element to update with AI suggestion
let lastAISuggestion = ''; // Store the last AI suggestion for feedback
let lastAISectionType = ''; // Store the section type for which feedback is being given

// --- Helper Functions ---

/**
 * Creates and appends a new work experience input block to the DOM.
 * @param {object} initialData - Optional object to pre-fill the fields (e.g., {title: '', company: '', ...}).
 */
let experienceCount = 0;
function createExperienceBlock(initialData = {}) {
    experienceCount++;
    const div = document.createElement('div');
    div.className = 'border-b pb-4 mb-4 last:border-b-0 last:pb-0 space-y-3';
    div.innerHTML = `
        <div>
            <label for="exp-title-${experienceCount}" class="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
            <input type="text" id="exp-title-${experienceCount}" class="exp-title" placeholder="Software Engineer" value="${initialData.title || ''}">
        </div>
        <div>
            <label for="exp-company-${experienceCount}" class="block text-sm font-medium text-gray-700 mb-1">Company</label>
            <input type="text" id="exp-company-${experienceCount}" class="exp-company" placeholder="Tech Innovations Inc." value="${initialData.company || ''}">
        </div>
        <div>
            <label for="exp-duration-${experienceCount}" class="block text-sm font-medium text-gray-700 mb-1">Duration</label>
            <input type="text" id="exp-duration-${experienceCount}" class="exp-duration" placeholder="Jan 2020 - Present" value="${initialData.duration || ''}">
        </div>
        <div>
            <label for="exp-description-${experienceCount}" class="block text-sm font-medium text-gray-700 mb-1">Description (Key responsibilities & achievements)</label>
            <textarea id="exp-description-${experienceCount}" class="exp-description" placeholder="Developed and maintained..." rows="3">${initialData.description || ''}</textarea>
            <button class="mt-4 btn-purple ai-refine-exp-btn">AI Refine Description</button>
        </div>
    `;
    experienceContainer.appendChild(div);

    // Attach event listener for the new AI Refine button
    const refineBtn = div.querySelector('.ai-refine-exp-btn');
    const descriptionTextArea = div.querySelector('.exp-description');
    refineBtn.addEventListener('click', () => {
        const title = div.querySelector('.exp-title').value;
        const company = div.querySelector('.exp-company').value;
        const duration = div.querySelector('.exp-duration').value;
        const description = descriptionTextArea.value;
        generateAISuggestion('experience', { title, company, duration, description }, descriptionTextArea);
    });
}

/**
 * Creates and appends a new education input block to the DOM.
 * @param {object} initialData - Optional object to pre-fill the fields.
 */
let educationCount = 0;
function createEducationBlock(initialData = {}) {
    educationCount++;
    const div = document.createElement('div');
    div.className = 'border-b pb-4 mb-4 last:border-b-0 last:pb-0 space-y-3';
    div.innerHTML = `
        <div>
            <label for="edu-degree-${educationCount}" class="block text-sm font-medium text-gray-700 mb-1">Degree/Major</label>
            <input type="text" id="edu-degree-${educationCount}" class="edu-degree" placeholder="M.Sc. Computer Science" value="${initialData.degree || ''}">
        </div>
        <div>
            <label for="edu-institution-${educationCount}" class="block text-sm font-medium text-gray-700 mb-1">Institution</label>
            <input type="text" id="edu-institution-${educationCount}" class="edu-institution" placeholder="University of Tech" value="${initialData.institution || ''}">
        </div>
        <div>
            <label for="edu-year-${educationCount}" class="block text-sm font-medium text-gray-700 mb-1">Year/Graduation</label>
            <input type="text" id="edu-year-${educationCount}" class="edu-year" placeholder="2019" value="${initialData.year || ''}">
        </div>
    `;
    educationContainer.appendChild(div);
}

// Initialize with one experience and one education block if containers are empty on load
document.addEventListener('DOMContentLoaded', () => {
    if (experienceContainer.children.length === 0) {
        createExperienceBlock();
    }
    if (educationContainer.children.length === 0) {
        createEducationBlock();
    }
    // Update the download button text on load
    downloadResumeBtn.textContent = 'Download Resume (PDF)';
});


// --- Core AI Logic ---

/**
 * Sets the loading state for AI suggestion and updates relevant UI elements.
 * @param {boolean} loading - True if loading, false otherwise.
 * @param {string} sectionType - The type of section being generated (e.g., 'summary', 'experience').
 */
function setLoadingState(loading, sectionType = '') {
    isLoading = loading;
    aiErrorDisplay.classList.add('hidden'); // Clear previous errors
    if (loading) {
        aiSuggestionBox.classList.remove('hidden');
        aiSuggestionDisplay.innerHTML = `<span class="loading-spinner"></span> Generating suggestion for ${sectionType}...`;
        applySuggestionBtn.classList.add('hidden'); // Hide apply button while loading
        provideFeedbackBtn.classList.add('hidden'); // Hide feedback button while loading
    } else {
        // If not loading, but no suggestion, hide the box (e.g., after error)
        if (aiSuggestionDisplay.innerText === '' || aiErrorDisplay.innerText !== '') {
             aiSuggestionBox.classList.add('hidden');
        } else {
            applySuggestionBtn.classList.remove('hidden');
            provideFeedbackBtn.classList.remove('hidden'); // Show feedback button if there's a suggestion
        }
    }
    // Disable relevant buttons while loading
    const allAiButtons = document.querySelectorAll('.btn-purple, .ai-refine-exp-btn');
    allAiButtons.forEach(btn => {
        if (loading) {
            btn.classList.add('btn-disabled');
            btn.disabled = true;
        } else {
            btn.classList.remove('btn-disabled');
            btn.disabled = false;
        }
    });
    // Disable ATS button if an AI suggestion is loading
    if (loading && (sectionType === 'summary' || sectionType === 'experience' || sectionType === 'skills')) {
        checkAtsBtn.classList.add('btn-disabled');
        checkAtsBtn.disabled = true;
    } else {
        checkAtsBtn.classList.remove('btn-disabled');
        checkAtsBtn.disabled = false;
    }
}

/**
 * Calls the Gemini API to generate AI suggestions for a given resume section.
 * @param {string} sectionType - The type of resume section ('summary', 'experience', 'skills').
 * @param {object|string} content - The current content of the section or an object for experience.
 * @param {HTMLElement} targetElement - The textarea DOM element to which the suggestion will be applied.
 */
async function generateAISuggestion(sectionType, content, targetElement) {
    setLoadingState(true, sectionType);
    currentAiTargetElement = targetElement; // Store reference to the textarea to update
    lastAISectionType = sectionType; // Store section type for feedback

    let prompt = '';
    const name = nameInput.value;
    const contact = contactInput.value;
    const summary = summaryTextarea.value;
    const skills = skillsTextarea.value;

    // Gather all experience descriptions for context for more relevant AI suggestions
    const allExperienceDescriptions = Array.from(document.querySelectorAll('.exp-description'))
                                            .map(el => el.value)
                                            .filter(text => text.trim() !== '')
                                            .join('\n');

    if (sectionType === 'summary') {
        prompt = `Given the following information, write a concise and impactful professional summary (3-4 sentences), focusing on key achievements and career goals.
        Name: ${name}
        Contact: ${contact}
        Skills: ${skills}
        Existing Summary (if any): ${summary}
        Relevant Experience Highlights: ${allExperienceDescriptions}
        `;
    } else if (sectionType === 'experience' && content) {
        prompt = `Refine the following work experience description for a resume, making it action-oriented, quantifiable, and highlighting achievements. Use strong action verbs.
        Job Title: ${content.title}
        Company: ${content.company}
        Duration: ${content.duration}
        Existing Description: ${content.description}
        `;
    } else if (sectionType === 'skills') {
        prompt = `Review the following skills and suggest additional relevant technical and soft skills for a professional resume. Categorize them if appropriate (e.g., Programming Languages, Frameworks, Tools, Soft Skills).
        Existing Skills: ${skills}
        Consider context from summary and experience:
        Summary: ${summary}
        Experience Descriptions: ${allExperienceDescriptions}
        `;
    } else {
        prompt = `Generate a professional and concise text for the "${sectionType}" section of a resume, based on the provided content: "${JSON.stringify(content)}". Focus on clarity and impact.`;
    }

    try {
        let chatHistory = [];
        chatHistory.push({ role: "user", parts: [{ text: prompt }] });
        const payload = { contents: chatHistory };
        const apiKey = ""; // Canvas will automatically provide the API key at runtime
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`API error: ${errorData.error.message || response.statusText}`);
        }

        const result = await response.json();

        if (result.candidates && result.candidates.length > 0 &&
            result.candidates[0].content && result.candidates[0].content.parts &&
            result.candidates[0].content.parts.length > 0) {
            const text = result.candidates[0].content.parts[0].text;
            aiSuggestionDisplay.innerText = text;
            lastAISuggestion = text; // Store the suggestion for feedback
            aiErrorDisplay.classList.add('hidden');
        } else {
            aiSuggestionDisplay.innerText = '';
            lastAISuggestion = '';
            aiErrorDisplay.innerText = 'No valid AI response received.';
            aiErrorDisplay.classList.remove('hidden');
        }
    } catch (err) {
        console.error("Error calling Gemini API:", err);
        aiSuggestionDisplay.innerText = '';
        lastAISuggestion = '';
        aiErrorDisplay.innerText = `Failed to generate suggestion: ${err.message}`;
        aiErrorDisplay.classList.remove('hidden');
    } finally {
        setLoadingState(false);
    }
}

/**
 * Applies the current AI suggestion to the target input field.
 */
function applyAISuggestion() {
    const suggestionText = aiSuggestionDisplay.innerText;
    if (suggestionText && currentAiTargetElement) {
        currentAiTargetElement.value = suggestionText;
        aiSuggestionDisplay.innerText = ''; // Clear the suggestion display
        aiSuggestionBox.classList.add('hidden'); // Hide the suggestion box
        currentAiTargetElement = null; // Clear target element reference
    }
}

// --- ATS Compatibility Check Logic ---
/**
 * Gathers resume content and sends it to the AI for ATS compatibility analysis.
 */
async function checkATSCompatibility() {
    atsResultBox.classList.remove('hidden');
    atsResultDisplay.innerHTML = `<span class="loading-spinner"></span> Analyzing resume for ATS compatibility...`;
    atsErrorDisplay.classList.add('hidden');

    // Gather all resume data
    const resumeContent = {
        name: nameInput.value,
        contact: contactInput.value,
        summary: summaryTextarea.value,
        experience: [],
        education: [],
        skills: skillsTextarea.value
    };

    const experienceBlocks = experienceContainer.querySelectorAll('.space-y-3');
    experienceBlocks.forEach(block => {
        const title = block.querySelector('.exp-title').value;
        const company = block.querySelector('.exp-company').value;
        const duration = block.querySelector('.exp-duration').value;
        const description = block.querySelector('.exp-description').value;
        if (title || company || duration || description) {
            resumeContent.experience.push({ title, company, duration, description });
        }
    });

    const educationBlocks = educationContainer.querySelectorAll('.space-y-3');
    educationBlocks.forEach(block => {
        const degree = block.querySelector('.edu-degree').value;
        const institution = block.querySelector('.edu-institution').value;
        const year = block.querySelector('.edu-year').value;
        if (degree || institution || year) {
            resumeContent.education.push({ degree, institution, year });
        }
    });

    const prompt = `Analyze the following resume content for Applicant Tracking System (ATS) compatibility. Provide specific feedback on:
    1. Clarity and standard formatting.
    2. Use of keywords (and suggest missing common ones for a general role if applicable).
    3. Readability by machines (e.g., avoiding complex graphics, clear section headers).
    4. Any red flags that might hinder ATS parsing.
    Provide a score (e.g., 1-10 or Poor, Fair, Good, Excellent) and actionable recommendations.

    Resume Content:
    Name: ${resumeContent.name}
    Contact: ${resumeContent.contact}
    Summary: ${resumeContent.summary}
    Experience: ${resumeContent.experience.map(exp => `${exp.title}, ${exp.company}, ${exp.duration}, ${exp.description}`).join('\n')}
    Education: ${resumeContent.education.map(edu => `${edu.degree}, ${edu.institution}, ${edu.year}`).join('\n')}
    Skills: ${resumeContent.skills}
    `;

    checkAtsBtn.classList.add('btn-disabled'); // Disable button during loading
    checkAtsBtn.disabled = true;

    try {
        let chatHistory = [];
        chatHistory.push({ role: "user", parts: [{ text: prompt }] });
        const payload = { contents: chatHistory };
        const apiKey = ""; // Canvas will automatically provide the API key at runtime
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(`API error: ${errorData.error.message || response.statusText}`);
        }

        const result = await response.json();

        if (result.candidates && result.candidates.length > 0 &&
            result.candidates[0].content && result.candidates[0].content.parts &&
            result.candidates[0].content.parts.length > 0) {
            const text = result.candidates[0].content.parts[0].text;
            atsResultDisplay.innerText = text;
            atsErrorDisplay.classList.add('hidden');
        } else {
            atsResultDisplay.innerText = '';
            atsErrorDisplay.innerText = 'No valid ATS analysis received.';
            atsErrorDisplay.classList.remove('hidden');
        }
    } catch (err) {
        console.error("Error calling Gemini API for ATS check:", err);
        atsResultDisplay.innerText = '';
        atsErrorDisplay.innerText = `Failed to perform ATS check: ${err.message}`;
        atsErrorDisplay.classList.remove('hidden');
    } finally {
        checkAtsBtn.classList.remove('btn-disabled'); // Re-enable button
        checkAtsBtn.disabled = false;
    }
}


// --- Feedback Loop Logic ---
/**
 * Shows the feedback modal.
 */
function showFeedbackModal() {
    feedbackModal.classList.remove('hidden');
    feedbackTextarea.value = ''; // Clear previous feedback
}

/**
 * Hides the feedback modal.
 */
function hideFeedbackModal() {
    feedbackModal.classList.add('hidden');
}

/**
 * Collects and "submits" user feedback on AI suggestions.
 * In a real app, this would send data to a backend.
 */
async function submitFeedback() {
    const feedback = feedbackTextarea.value;
    if (!feedback.trim()) {
        alert('Please provide some feedback before submitting.');
        return;
    }

    // Capture the current value of the target element, which would reflect user edits
    const usersEditedContent = currentAiTargetElement ? currentAiTargetElement.value : 'N/A (No target element)';

    // In a real application, you would send this data to a backend server for ML model training.
    // For this demonstration, we'll just log it to the console.
    console.log("Feedback Submitted:");
    console.log("  Original AI Suggestion (for section '" + lastAISectionType + "'):", lastAISuggestion);
    console.log("  User's Final Edited Content:", usersEditedContent); // Explicitly log user's edited content
    console.log("  User Feedback:", feedback);
    console.log("  Current Resume Data (context):", { // Provide relevant context for feedback
        name: nameInput.value,
        summary: summaryTextarea.value,
        skills: skillsTextarea.value,
        // You could add more detailed context, e.g., the specific experience block being refined
    });

    // Simulate sending feedback and then hide the modal
    alert('Thank you for your feedback! It helps improve our AI suggestions.');
    hideFeedbackModal();

    // Optionally, clear the last AI suggestion so feedback is tied to a new one
    lastAISuggestion = '';
    lastAISectionType = '';
}


// --- Download Functionality (PDF) ---
/**
 * Generates and downloads the resume as a PDF using jsPDF, applying selected template styles.
 */
function downloadResume() {
    // Ensure jsPDF is loaded before trying to use it
    if (typeof window.jspdf === 'undefined') {
        alert('PDF generation library (jsPDF) is not loaded. Please ensure internet connectivity or refresh the page.');
        console.error('jsPDF library (window.jspdf) is undefined.');
        return;
    }
    const { jsPDF } = window.jspdf;

    const doc = new jsPDF();
    let yPos = 20; // Initial Y position, increased for better top margin
    const margin = 20; // Increased margin for better aesthetics
    const maxWidth = doc.internal.pageSize.width - (2 * margin); // Max width for text content, adapted for new margin

    const selectedTemplate = pdfTemplateSelect.value; // Get selected template

    // Define color palettes and font styles for templates
    const templateStyles = {
        'modern': {
            primaryColor: [49, 130, 206], // Blue-600
            secondaryColor: [71, 85, 105], // Slate-600
            accentColor: [99, 102, 241], // Indigo-500
            headerFontSize: 24,
            sectionTitleFontSize: 14,
            contentFontSize: 10,
            lineHeight: 1.2,
            fontStyle: "normal",
            sectionLineColor: [99, 102, 241], // Indigo line
            sectionLineWidth: 0.4
        },
        'classic': {
            primaryColor: [30, 41, 59], // Slate-900
            secondaryColor: [51, 65, 85], // Slate-700
            accentColor: [100, 116, 139], // Slate-500 (subtle accent)
            headerFontSize: 20,
            sectionTitleFontSize: 13,
            contentFontSize: 11,
            lineHeight: 1.15,
            fontStyle: "normal",
            sectionLineColor: [203, 213, 225], // Light gray line
            sectionLineWidth: 0.2
        },
        'creative': {
            primaryColor: [239, 68, 68], // Red-500
            secondaryColor: [75, 85, 99], // Gray-700
            accentColor: [59, 130, 246], // Blue-500
            headerFontSize: 28,
            sectionTitleFontSize: 15,
            contentFontSize: 10,
            lineHeight: 1.3,
            fontStyle: "bolditalic", // Italic for a creative touch
            sectionLineColor: [239, 68, 68], // Red line
            sectionLineWidth: 0.6
        }
    };

    const currentTemplate = templateStyles[selectedTemplate] || templateStyles['modern']; // Default to modern

    /**
     * Applies template-specific styling to the PDF document on each page.
     * @param {jsPDF} currentDoc - The jsPDF document instance.
     * @param {object} templateStyle - The style object for the current template.
     */
    const applyPageStyles = (currentDoc, templateStyle) => {
        currentDoc.setFont("helvetica", templateStyle.fontStyle);
        currentDoc.setTextColor(...templateStyle.primaryColor);
        currentDoc.setDrawColor(...templateStyle.sectionLineColor);
        currentDoc.setLineWidth(templateStyle.sectionLineWidth);
    };

    applyPageStyles(doc, currentTemplate); // Apply initial template styles

    // --- Name and Contact ---
    doc.setFontSize(currentTemplate.headerFontSize);
    doc.setFont("helvetica", "bold"); // Name always bold
    doc.setTextColor(...currentTemplate.primaryColor);
    doc.text(nameInput.value || "Your Name", margin, yPos);
    yPos += currentTemplate.headerFontSize / 2; // Adjusted spacing

    doc.setFontSize(currentTemplate.contentFontSize + 1); // Slightly larger for contact
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...currentTemplate.secondaryColor);
    doc.text(contactInput.value || "Your Contact Info", margin, yPos);
    yPos += currentTemplate.contentFontSize * currentTemplate.lineHeight * 2; // More space after contact


    // Function to add a section with proper styling
    const addSection = (title, content, isExperience = false, currentBlock = null) => {
        // Line under the previous section, if any, based on modern template style
        if (selectedTemplate === 'modern' && yPos > margin + 50) { // Don't draw line at very top
            doc.setDrawColor(...currentTemplate.sectionLineColor);
            doc.setLineWidth(currentTemplate.sectionLineWidth);
            doc.line(margin, yPos - 10, doc.internal.pageSize.width - margin, yPos - 10);
            yPos += 5; // Add a little space after the line
        }

        // Check for page overflow before adding a new section header
        const estimatedSectionHeight = isExperience ? 40 : 20; // More height for experience
        if (yPos + estimatedSectionHeight > doc.internal.pageSize.height - margin) {
            doc.addPage();
            yPos = margin; // Reset Y position for new page
            applyPageStyles(doc, currentTemplate); // Reapply styles for new page
        }

        // Section Title
        doc.setFontSize(currentTemplate.sectionTitleFontSize);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(...currentTemplate.accentColor); // Use accent color for section titles
        doc.text(title, margin, yPos);
        yPos += currentTemplate.sectionTitleFontSize / 1.5; // Spacing after title

        // Section Content
        doc.setFontSize(currentTemplate.contentFontSize);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(...currentTemplate.secondaryColor);

        if (isExperience && currentBlock) {
            doc.setFont("helvetica", "bold");
            doc.text(`${currentBlock.title} at ${currentBlock.company}`, margin + 5, yPos);
            doc.setFont("helvetica", "normal");
            doc.text(currentBlock.duration, margin + maxWidth - doc.getTextWidth(currentBlock.duration), yPos); // Align duration to right
            yPos += currentTemplate.contentFontSize * currentTemplate.lineHeight;

            const descriptionLines = doc.splitTextToSize(currentBlock.description, maxWidth - 10); // Indent description
            doc.text(descriptionLines, margin + 10, yPos);
            yPos += (descriptionLines.length * currentTemplate.contentFontSize * currentTemplate.lineHeight) + 8; // Extra spacing
        } else {
            const contentLines = doc.splitTextToSize(content, maxWidth);
            doc.text(contentLines, margin, yPos);
            yPos += (contentLines.length * currentTemplate.contentFontSize * currentTemplate.lineHeight) + 10;
        }
    };


    // --- Professional Summary ---
    addSection("Professional Summary", summaryTextarea.value);

    // --- Work Experience ---
    addSection("Work Experience", ""); // Add title
    const experienceBlocks = experienceContainer.querySelectorAll('.space-y-3');
    experienceBlocks.forEach(block => {
        const title = block.querySelector('.exp-title').value;
        const company = block.querySelector('.exp-company').value;
        const duration = block.querySelector('.exp-duration').value;
        const description = block.querySelector('.exp-description').value;

        if (title || company || duration || description) {
             // Check for page overflow for the *next* experience item
            const estimatedItemHeight = (description.split('\n').length * currentTemplate.contentFontSize * currentTemplate.lineHeight) + 25; // Title + duration + description
            if (yPos + estimatedItemHeight > doc.internal.pageSize.height - margin) {
                doc.addPage();
                yPos = margin; // Reset Y position for new page
                applyPageStyles(doc, currentTemplate); // Reapply styles for new page
                doc.setFontSize(currentTemplate.sectionTitleFontSize); // Re-add section title on new page if needed
                doc.setFont("helvetica", "bold");
                doc.setTextColor(...currentTemplate.accentColor);
                doc.text("Work Experience (Cont.)", margin, yPos);
                yPos += currentTemplate.sectionTitleFontSize / 1.5;
            }

            doc.setFontSize(currentTemplate.contentFontSize);
            doc.setTextColor(...currentTemplate.secondaryColor);

            doc.setFont("helvetica", "bold");
            doc.text(title, margin + 5, yPos); // Job Title
            doc.setFont("helvetica", "normal");
            doc.text(company, margin + 5 + doc.getTextWidth(title) + 2, yPos); // Company next to title
            doc.text(duration, doc.internal.pageSize.width - margin - doc.getTextWidth(duration), yPos); // Duration right aligned
            yPos += currentTemplate.contentFontSize * currentTemplate.lineHeight;

            const descriptionLines = doc.splitTextToSize(description, maxWidth - 10);
            doc.text(descriptionLines, margin + 10, yPos); // Description indented
            yPos += (descriptionLines.length * currentTemplate.contentFontSize * currentTemplate.lineHeight) + 8;
        }
    });

    // --- Education ---
    addSection("Education", "");
    const educationBlocks = educationContainer.querySelectorAll('.space-y-3');
    educationBlocks.forEach(block => {
        const degree = block.querySelector('.edu-degree').value;
        const institution = block.querySelector('.edu-institution').value;
        const year = block.querySelector('.edu-year').value;

        if (degree || institution || year) {
            // Check for page overflow
            if (yPos + 15 > doc.internal.pageSize.height - margin) {
                doc.addPage();
                yPos = margin; // Reset Y position for new page
                applyPageStyles(doc, currentTemplate); // Reapply styles for new page
                doc.setFontSize(currentTemplate.sectionTitleFontSize);
                doc.setFont("helvetica", "bold");
                doc.setTextColor(...currentTemplate.accentColor);
                doc.text("Education (Cont.)", margin, yPos);
                yPos += currentTemplate.sectionTitleFontSize / 1.5;
            }
            doc.setFontSize(currentTemplate.contentFontSize);
            doc.setTextColor(...currentTemplate.secondaryColor);
            doc.setFont("helvetica", "bold");
            doc.text(`${degree}`, margin + 5, yPos);
            doc.setFont("helvetica", "normal");
            doc.text(`${institution} (${year})`, margin + 5 + doc.getTextWidth(degree) + 2, yPos);
            yPos += currentTemplate.contentFontSize * currentTemplate.lineHeight + 5;
        }
    });

    // --- Skills ---
    addSection("Skills", skillsTextarea.value);


    // Save the PDF
    doc.save(`${nameInput.value.replace(/\s/g, '_') || 'resume'}.pdf`);
}

// --- Event Listeners ---
aiSuggestSummaryBtn.addEventListener('click', () => {
    generateAISuggestion('summary', summaryTextarea.value, summaryTextarea);
});

aiSuggestSkillsBtn.addEventListener('click', () => {
    generateAISuggestion('skills', skillsTextarea.value, skillsTextarea);
});

applySuggestionBtn.addEventListener('click', applyAISuggestion);
provideFeedbackBtn.addEventListener('click', showFeedbackModal); // Feedback button listener

checkAtsBtn.addEventListener('click', checkATSCompatibility); // ATS check button listener

addExperienceBtn.addEventListener('click', () => createExperienceBlock());
addEducationBtn.addEventListener('click', () => createEducationBlock());

downloadResumeBtn.addEventListener('click', downloadResume);

// Feedback modal listeners
cancelFeedbackBtn.addEventListener('click', hideFeedbackModal);
submitFeedbackBtn.addEventListener('click', submitFeedback);
