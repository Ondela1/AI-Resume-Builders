# AI Resume Builder

A Pen created on CodePen.

Original URL: [https://codepen.io/Ondela-Citywayo/pen/wBaQRzM](https://codepen.io/Ondela-Citywayo/pen/wBaQRzM).

